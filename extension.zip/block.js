// Block ads by removing elements with ad-related classes
const adsClasses = ['ad', 'ads', 'advert', 'ad-banner', 'ad-container', 'ad-label', 'ad-placeholder', 'ad-slot', 'ad-wrapper', 'advertisement', 'taboola'];

adsClasses.forEach(function(className) {
  const elements = document.getElementsByClassName(className);
  for (let i = 0; i < elements.length; i++) {
    elements[i].remove();
  }
});

// Block ads by hiding elements with ad-related IDs
const adsIds = ['ad', 'ads', 'advert', 'ad-banner', 'ad-container', 'ad-label', 'ad-placeholder', 'ad-slot', 'ad-wrapper', 'advertisement', 'taboola'];

adsIds.forEach(function(id) {
  const element = document.getElementById(id);
  if (element) {
    element.style.display = 'none';
  }
});

// Block ads by hiding elements with ad-related attributes
const adsAttributes = ['data-ad', 'data-ads', 'data-advert', 'data-ad-banner', 'data-ad-container', 'data-ad-label', 'data-ad-placeholder', 'data-ad-slot', 'data-ad-wrapper', 'data-advertisement'];

adsAttributes.forEach(function(attribute) {
  const elements = document.querySelectorAll(`[${attribute}]`);
  for (let i = 0; i < elements.length; i++) {
    elements[i].style.display = 'none';
  }
});

// Block ads by hiding elements with ad-related tag names
const adsTagNames = ['iframe', 'ins'];

adsTagNames.forEach(function(tagName) {
  const elements = document.getElementsByTagName(tagName);
  for (let i = 0; i < elements.length; i++) {
    elements[i].style.display = 'none';
  }
});
